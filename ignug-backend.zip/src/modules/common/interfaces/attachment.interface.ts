export interface AttachmentInterface {
    path?: string;
    filename: string;
    file?: Buffer;
}
