import { InstitutionDto } from '@core/dto';

export class SeedInstitutionDto extends InstitutionDto {}
