import {EnrollmentDetailStateDto} from "@core/dto";
export class CreateEnrollmentDetailStateDto extends EnrollmentDetailStateDto {}