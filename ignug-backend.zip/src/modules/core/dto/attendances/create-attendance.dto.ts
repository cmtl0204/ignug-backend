import { GradeDto } from '@core/dto';
export class CreateAttendanceDto extends GradeDto {}
