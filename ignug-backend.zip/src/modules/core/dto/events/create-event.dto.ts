import { EventDto } from '@core/dto';

export class CreateEventDto extends EventDto {}
