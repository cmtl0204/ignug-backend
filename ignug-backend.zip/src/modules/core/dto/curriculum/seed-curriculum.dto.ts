import { CurriculumDto } from '@core/dto';

export class SeedCurriculumDto extends CurriculumDto {}
