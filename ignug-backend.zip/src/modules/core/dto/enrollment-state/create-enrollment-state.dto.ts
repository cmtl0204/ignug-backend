import { EnrollmentStateDto} from '@core/dto';
export class CreateEnrollmentStateDto extends EnrollmentStateDto {}