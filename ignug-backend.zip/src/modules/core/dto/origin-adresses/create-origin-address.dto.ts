import {OriginAddressDto} from "./origin-address.dto";

export class CreateOriginAddressDto extends OriginAddressDto{}
