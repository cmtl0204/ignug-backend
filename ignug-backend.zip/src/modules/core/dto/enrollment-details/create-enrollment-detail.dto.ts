import { EnrollmentsDetailDto } from '@core/dto';
export class CreateEnrollmentsDetailDto extends EnrollmentsDetailDto {

}