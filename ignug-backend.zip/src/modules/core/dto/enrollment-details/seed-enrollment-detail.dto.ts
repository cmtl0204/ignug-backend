import { EnrollmentsDetailDto } from '@core/dto';

export class SeedEnrollmentsDetailDto extends EnrollmentsDetailDto {}
