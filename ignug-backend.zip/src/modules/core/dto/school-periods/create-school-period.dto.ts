import { SchoolPeriodDto } from '@core/dto';

export class CreateSchoolPeriodDto extends SchoolPeriodDto {}
