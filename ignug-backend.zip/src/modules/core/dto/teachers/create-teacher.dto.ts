import { TeacherDto } from '@core/dto';

export class CreateTeacherDto extends TeacherDto {}
