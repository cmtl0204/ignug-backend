import { ClassroomDto } from '@core/dto';

export class SeedClassroomDto extends ClassroomDto {}
