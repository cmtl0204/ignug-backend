import { ClassroomDto } from "./classroom.dto";

export class CreateClassroomDto extends ClassroomDto {}
