import { GradeDto } from '@core/dto';
export class CreateGradeDto extends GradeDto {}