import { LocationDto } from '@core/dto';

export class CreateLocationDto {}
