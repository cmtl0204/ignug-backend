import { InstitutionDto } from '@core/dto';

export class CreateInstitutionDto extends InstitutionDto {}
