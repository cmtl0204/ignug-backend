import { PartialDto } from "./partial.dto";

export class CreatePartialDto extends PartialDto {}
