import { PartialDto } from '@core/dto';

export class SeedPartialDto extends PartialDto {}
