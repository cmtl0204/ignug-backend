import { CareerDto } from '@core/dto';

export class SeedCareerDto extends CareerDto {

}
