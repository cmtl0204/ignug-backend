import { CareerDto } from '@core/dto';

export class CreateCareerDto extends CareerDto {}
