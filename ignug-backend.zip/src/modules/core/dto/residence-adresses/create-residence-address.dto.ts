import {ResidenceAddressDto} from "./residence-address.dto";

export class CreateResidenceAddressDto extends ResidenceAddressDto{}
