import { SubjectDto } from '@core/dto';

export class SeedSubjectDto extends SubjectDto {}
