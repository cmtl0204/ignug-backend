import { SubjectDto } from '@core/dto';

export class CreateSubjectDto extends SubjectDto {}
