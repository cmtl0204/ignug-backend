import { InformationStudentDto } from './information-student.dto';

export class CreateInformationStudentDto extends InformationStudentDto {}
