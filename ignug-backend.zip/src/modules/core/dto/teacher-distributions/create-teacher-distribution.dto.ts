import { TeacherDistributionDto } from '@core/dto';

export class CreateTeacherDistributionDto extends TeacherDistributionDto {}
