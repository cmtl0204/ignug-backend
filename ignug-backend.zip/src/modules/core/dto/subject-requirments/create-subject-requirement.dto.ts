import { SubjectRequirementDto } from './subject-requirement.dto';

export class CreateSubjectRequirementDto extends SubjectRequirementDto {}
