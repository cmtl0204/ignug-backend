import { SubjectRequirementDto } from './subject-requirement.dto';

export class SeedSubjectRequirementDto extends SubjectRequirementDto {}
