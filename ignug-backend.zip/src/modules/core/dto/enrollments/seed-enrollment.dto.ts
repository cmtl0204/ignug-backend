import { EnrollmentDto } from '@core/dto';

export class SeedEnrollmentDto extends EnrollmentDto {}
