import { EnrollmentDto } from "./enrollment.dto";

export class CreateEnrollmentDto extends EnrollmentDto {}