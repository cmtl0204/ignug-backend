export interface PayloadTokenModel {
  id: string;
  iat?: number;
  exp?: number;
}
