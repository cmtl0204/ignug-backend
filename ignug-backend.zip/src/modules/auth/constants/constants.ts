export const IS_PUBLIC_ROUTE_KEY = 'isPublic';
export const ROLES_KEY = 'roles';
export const MAX_ATTEMPTS = 3;
