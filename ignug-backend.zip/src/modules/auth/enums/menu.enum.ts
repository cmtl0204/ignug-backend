export enum MenuTypeEnum {
  LEFT_SIDE = 'left_side',
}
