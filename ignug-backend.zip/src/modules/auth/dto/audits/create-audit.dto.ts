import {AuditDto} from "@auth/dto";

export class CreateAuditDto extends AuditDto {}
