export const environments = {
  dev: '.env',
  test: '.test.env',
  prod: '.prod.env',
  appVersion: '2.2.37',
  appName: 'IGNUG',
  serviceUnavailable: false,
};
