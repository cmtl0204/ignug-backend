export interface ServiceResponseHttpModel {
  data: any;
  pagination?: any;
}
