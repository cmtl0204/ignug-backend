export enum FileTypeEnum {
  PG_DATA_SOURCE = 'PG_DATA_SOURCE',
}
