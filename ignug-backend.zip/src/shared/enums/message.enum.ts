export enum MessageEnum {
  NOT_FOUND = 'Registro no encontrado',
  EXISTS_OPEN_SCHOOL_PERIOD = 'Solo puede haber un Periodo Lectivo Abierto y existe uno',
  EXISTS_CLOSE_SCHOOL_PERIOD = 'El Periodo Lectivo ya se encuentra cerrado',
  AT_LEST_ONE_OPEN_SCHOOL_PERIOD = 'Debe haber un Periodo Lectivo Abierto',
}
