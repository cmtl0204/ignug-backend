export enum CacheEnum {
  CATALOGUES = 'catalogues',
  LOCATIONS = 'locations',
}
